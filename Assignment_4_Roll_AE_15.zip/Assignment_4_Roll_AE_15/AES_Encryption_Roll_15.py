"""
Author : Sadnan Kibria Kawshik
Roll:AE-15
Course : Cryptography & Security Lab
Labwork : Assignment - 4(AES Encryption Implementation)

Brief description :
      AES(Advanced Encryption Scheme) is a block cipher encryption scheme in which 16 Byte of plain text block is
      used to encrypt using a 16 Byte(AES-128) or 24 Byte(AES-192) or 32 Byte(AES-256) key.This is the implementation
      of AES-128 with a 16 Byte Plain Text and 16 Byte key.In this process they plain text block is divided into a 4*4 matrix
      each cell indicating a byte.AES-128 is done in n=10 rounds where each of n-1 rounds contain 4 operations :
      Substitution Byte,Shift Rows,Mix Column and AddRoundKey.The last round contains 3 operations :
      Substitution Byte,Shift Rows and AddRoundKey.Before that key is expanded each phase and total 44 words
      of key is generated. Before that a round 0 is done in which addRoundKey function is performed between key and
      the plain text.


      In this problem (a) The round functions (Substitution Byte,Shift Rows,Mix Column and AddRoundKey) is implemented
      (b)Then key expansion is done and AES encryption is implemented and (c) The avalanche effect is shown using
      the example from book
"""
import GaloisFieldCalculator  # Galois field(2^8) calculator class

calculator = GaloisFieldCalculator.GF_Calculator()  # Galois field(2^8) calculator


def sbox_mul(val):
    '''Function to do internal calculation to generate sbox'''
    bin_val = bin(val)[2:].zfill(8)  # binary value of multiplicative inverse of yx

    result = ""
    bin_val = bin_val[::-1]  # reverse of that value

    c = bin(99)[2:].zfill(8)[::-1]  # reverse of binary value (99) which is in hexadecimal (63)

    for i in range(len(bin_val)):
        # bit generation using equation b i' = b i ^b (i + 4) mod 8 ^b (i + 5) mod 8^ b (i + 6) mod 8^ b (i + 7) mod 8 ^ c i
        x = int(bin_val[i]) ^ int(bin_val[(i + 4) % 8]) ^ int(bin_val[(i + 5) % 8]) ^ int(bin_val[(i + 6) % 8]) ^ int(
            bin_val[(i + 7) % 8]) ^ int(c[i])
        result = result + str(x)

    result = result[::-1]  # Byte value of that cell

    return hex(int(result, 2))[2:].zfill(2)  # Hexa representation of that byte


def generate_sbox():
    '''Function to generate sbox which will be used in subByte function'''
    sbox = list()  # 16*16 list of sbox
    for i in range(0, 16):
        value = list()
        for j in range(0, 16):
            temp = bin(i)[2:].zfill(4) + bin(j)[2:].zfill(4)  # forming yx value using (i,j)
            temp_int = int(temp, 2)
            temp_inv = calculator.multiplicative_inverse(temp_int)  # calculating multiplicative inverse of yx
            value.append(sbox_mul(temp_inv))  # values for index i(i0,i1,...if)
        sbox.append(value)

    return sbox  # sbox in which each byte is represented as hexadecimal value


def mix_column(s):
    '''Mix column function '''
    forward_mat = [[2, 3, 1, 1], [1, 2, 3, 1], [1, 1, 2, 3], [3, 1, 1, 2]]  # matrix to multiplicate in mix column stage
    for i in range(0, 4):
        for j in range(0, 4):
            s[i][j] = int(s[i][j], 16)
    result = matrix_multiplication_galois(forward_mat, s)  # matrix multiplication in galois field((2^8)

    for i in range(0, 4):
        for j in range(0, 4):
            result[i][j] = hex(result[i][j])[2:].zfill(2)  # result stored in hexadecimal form
    return result


def matrix_multiplication_galois(A, B):
    '''Funtion to multiplicate 2 matrix in GF(2^8)'''
    result = list()
    for i in range(len(A)):
        val = list()
        for j in range(len(B[0])):
            p = 0
            for k in range(len(B)):
                p = p ^ calculator.multiplication(A[i][k], B[k][j])
            val.append(p)
        result.append(val)
    return result


def left_shift_forward(a, n):
    '''Function for left forward shift used in shift row function'''
    for i in range(n):
        a.append(a.pop(0))
    return a


def shift_rows(s):
    '''Function for shift row operation'''
    for i in range(len(s)):
        s[i] = left_shift_forward(s[i], i)

    return s


def add_round_key(s, k):
    '''Function for add round key operation of column wise xor with plain text(4*4) and key(4*4)'''
    for i in range(len(s)):
        for j in range(len(s)):
            s[j][i] = int(s[j][i], 16) ^ int(k[j][i], 16)
            s[j][i] = hex(s[j][i])[2:].zfill(2)  # result in hexadecimal form
    return s


def subByte_value(n, sbox):
    '''Function to provide sbox value from each byte
    It is used in Sub Byte operation '''
    x = int(n[0], 16)
    y = int(n[1], 16)

    z = sbox[x][y].zfill(2)  # each z is in hexadecimal form
    return z


def sub_byte(s, sbox):
    '''Sub Byte operation for a 4*4 matrix entry'''
    for i in range(0, 4):
        for j in range(0, 4):
            s[i][j] = subByte_value(s[i][j], sbox)
    return s


def round_constant_generator(n):
    '''Round constant generator for n rounds'''
    round_constant = list()
    round_constant.append(1)  # rc[0] = 1 here indexing starts from 0
    for i in range(1, n):
        round_constant.append(calculator.multiplication(2, round_constant[
            i - 1]))  # rc[j] = 2*rc[j-1] where multiplication done in GF(2^8)

    return round_constant


def word_xor(w1, w2):
    '''Function to xor 2 word value'''
    result = [0, 0, 0, 0]
    for i in range(0, 4):
        result[i] = hex(int(w1[i], 16) ^ int(w2[i], 16))[2:].zfill(2)

    return result  # result in hexadeximal form


def calculation_key_expansion(temp, sbox, n):
    '''Function for calculation if i%4 ==0 in key expansion'''
    temp_2 = temp.copy()
    temp_2 = left_shift_forward(temp_2, 1)  # left shift the bytes of word 1 time

    rc_array = round_constant_generator(10)  # round constant for 10 rounds
    result = [0, 0, 0, 0]  # result array
    rc = hex(rc_array[n])[2:]  # converting round constant for nth round as a hexadecimal value

    for i in range(0, 4):
        temp_2[i] = subByte_value(temp_2[i], sbox)  # substituting the bytes of the word using sbox

    for i in range(0, 4):
        # xoring the word [x,y,z,p] with rc = [rc[n],0,0,0]
        if i == 0:
            result[i] = hex(int(temp_2[i], 16) ^ int(rc, 16))[2:].zfill(2)
        else:
            result[i] = hex(int(temp_2[i], 16) ^ result[i])[2:].zfill(2)

    return result  # result is a hexadecimal word array


def key_expansion(key, sbox):
    '''Function for key expansion'''
    word = [[0, 0, 0, 0] for i in range(44)]  # word array of size 44
    round = 0  # used in round_constant calculation
    for i in range(0, 4):
        # initializing word[0:3]
        word[i] = [key[4 * i], key[4 * i + 1], key[4 * i + 2], key[4 * i + 3]]

    for i in range(4, 44):
        # calculating word[4:43]
        temp = word[i - 1]

        if i % 4 == 0:
            # if i%4 = =0 then temp = SubWord (RotWord (temp))
            temp = calculation_key_expansion(word[i - 1], sbox, round)
            round += 1
        word[i] = word_xor(word[i - 4], temp)  # w[i] = w[i–4] ^temp

    return word


def extract_key_array(w):
    '''Function to extract key from word list
    Used in aes encryption function'''
    key_array = [[0, 0, 0, 0] for i in range(4)]
    for i in range(0, 4):
        for j in range(0, 4):
            key_array[i][j] = w[j][i]
    return key_array


def matrix_to_list(a):
    '''Function to extract 16 size list from a 4*4 matrix'''
    a_list = [0] * 16
    k = 0
    for i in range(0, 4):
        for j in range(0, 4):
            a_list[k] = a[j][i]
            k += 1

    return a_list


def aes_encryption(plain_text, key):
    '''Function for AES encryption algorithm'''
    # Initialization
    plain_text_array = [[0, 0, 0, 0] for i in range(4)]
    key_array = [[0, 0, 0, 0] for i in range(4)]
    cipher_array = [[0, 0, 0, 0] for i in range(4)]
    cipher = [0] * 16

    plain_text_every_round = [[0] * 16 for i in
                              range(11)]  # array to store plain text in every round (round 0 -round10)

    sbox = generate_sbox()  # generating sbox
    print("\nFirst we will do the key expansion to create 44 words")
    word_list = key_expansion(key, sbox)
    print("\nWord List will be :")
    print(word_list)
    k = 0

    for i in range(0, 4):
        for j in range(0, 4):
            # converting plain text to plain text array
            plain_text_array[j][i] = plain_text[k]
            k += 1

    key_array = extract_key_array(word_list[0:4])  # key array (4*4) for round 0

    print("\nRound = 0")
    plain_text_array = add_round_key(plain_text_array, key_array)  # add round key for round0
    print("\nRound Key = ")
    print(key_array)

    print("\nAfter round 0 =  ")
    print(plain_text_array)
    plain_text_every_round[0] = matrix_to_list(plain_text_array)  # storing plain text after round0

    s = 4  # starting from 4 we will move forward

    for i in range(1, 10):
        # for round 1-9
        print("\nRound = ", i)
        plain_text_array = sub_byte(plain_text_array, sbox)  # sub byte
        print("\nAfter Sub byte = ")
        print(plain_text_array)
        plain_text_array = shift_rows(plain_text_array)  # shift rows
        print("\nAfter Shift Row = ")
        print(plain_text_array)

        plain_text_array = mix_column(plain_text_array)  # mix column
        print("\nAfter mix column = ")
        print(plain_text_array)
        key_array = extract_key_array(word_list[s:s + 4])  # key extract from word list
        print("\nRound Key = ")
        print(key_array)
        plain_text_array = add_round_key(plain_text_array, key_array)  # addRoundKey
        print("\nAfter Add Round Key = ")
        print(plain_text_array)
        plain_text_every_round[i] = matrix_to_list(plain_text_array)  # storing plain text after roundi
        s += 4

    print("\nRound = 10")  # Round 10
    plain_text_array = sub_byte(plain_text_array, sbox)  # subbyte
    print("\nAfter Sub byte = ")
    print(plain_text_array)
    plain_text_array = shift_rows(plain_text_array)  # shift row
    print("\nAfter Shift Row = ")
    print(plain_text_array)
    key_array = extract_key_array(word_list[s:s + 4])  # key for that round
    print("\nRound Key = ")
    print(key_array)
    plain_text_array = add_round_key(plain_text_array, key_array)  # add round key
    print("\nAfter Add Round Key = ")
    print(plain_text_array)
    plain_text_every_round[10] = matrix_to_list(
        plain_text_array)  # plain text at round 10 which is also the cipher text

    print("\nSo cipher text array will be : ")
    cipher_array = plain_text_array
    print(cipher_array)
    cipher = matrix_to_list(cipher_array)
    return cipher, plain_text_every_round


def bit_difference(w1, w2):
    '''Function for calculating bit difference between 2 bytes'''
    count = 0
    result = bin(int(w1, 16) ^ int(w2, 16))[2:]
    for i in range(len(result)):
        if result[i] == "1":
            count += 1
    return count


def list_wise_bit_difference(a, b):
    '''Function to calculate bit differnce between to 16 byte numbers'''
    count = 0
    for i in range(len(a)):
        count = count + bit_difference(a[i], b[i])

    return count


def avalanche_effect(plain_text, avalanche_plain_text, key, key_avalanche):
    '''Function for displaying avalanche effect'''
    print("\n\nAvalanche Effect : ")
    print("\nWe will first analyze avalanche effect in AES in terms of changing plain text")
    print(
        "\nHere plain text  = " + "".join(plain_text) + " and approximate plain text = " + "".join(
            avalanche_plain_text))
    print("\nThey have a bit difference of = ", list_wise_bit_difference(plain_text, avalanche_plain_text))
    print("\nHere the key is : "+"".join(key))

    print("\nNow we will calculate bit difference in each round : ")
    cipher_1, plain_text_every_round_1 = aes_encryption(plain_text, key)
    cipher_2, plain_text_every_round_2 = aes_encryption(avalanche_plain_text, key)

    print("\nHere cipher text for 1st plain text is = " + "".join(cipher_1))
    print("\nHere cipher text for 2nd plain text is = " + "".join(cipher_2))
    print()
    for i in range(0, 11):
        print("\nRound = ", i)
        print("\nChanged plain text for 1st case : " + "".join(plain_text_every_round_1[i]))
        print("\nChanged plain text for 2nd case : " + "".join(plain_text_every_round_2[i]))
        print("\nBit difference = ", list_wise_bit_difference(plain_text_every_round_1[i], plain_text_every_round_2[i]))

    print("\nWe will now analyze avalanche effect in AES in terms of changing key")
    print(
        "\nHere key  = " + "".join(key) + " and approximate key = " + "".join(
            key_avalanche))
    print("\nThey have a bit difference of = ", list_wise_bit_difference(key, key_avalanche))
    print("\nHere the plain text is = "+"".join(plain_text))

    print("\nNow we will calculate bit difference in each round : ")
    cipher_1, plain_text_every_round_1 = aes_encryption(plain_text, key)
    cipher_2, plain_text_every_round_2 = aes_encryption(plain_text, key_avalanche)

    print("\nHere cipher text for 1st key is = " + "".join(cipher_1))
    print("\nHere cipher text for 2nd key is = " + "".join(cipher_2))
    print()
    for i in range(0, 11):
        print("\nRound = ", i)
        print("\nChanged plain text for 1st case : " + "".join(plain_text_every_round_1[i]))
        print("\nChanged plain text for 2nd case : " + "".join(plain_text_every_round_2[i]))
        print("\nBit difference = ", list_wise_bit_difference(plain_text_every_round_1[i], plain_text_every_round_2[i]))


def main():
    print("Assignment -4")
    print("AES Encryption")
    plain_text = ["01", "23", "45", "67", "89", "ab", "cd", "ef", "fe", "dc", "ba", "98", "76", "54", "32", "10"]
    plain_text_avalanche = ["00", "23", "45", "67", "89", "ab", "cd", "ef", "fe", "dc", "ba", "98", "76", "54", "32",
                            "10"]
    key = ['0f', '15', '71', 'c9', '47', 'd9', 'e8', '59', '0c', 'b7', 'ad', 'd6', 'af', '7f', '67', '98']
    key_avalanche = ['0e', '15', '71', 'c9', '47', 'd9', 'e8', '59', '0c', 'b7', 'ad', 'd6', 'af', '7f', '67', '98']
    print("\nHere plain text is = " + "".join(plain_text) + " which is of ", len(plain_text), " Bytes")
    print("\nKey is  = " + "".join(key) + " which is of ", len(plain_text), " Bytes")

    print("\nNow through the AES encryption we will observe the implementation of each functions")

    cipher, plain_text_every_round = aes_encryption(plain_text, key)
    cipher_str = "".join(cipher)
    print("Cipher text will be = " + cipher_str)
    # print("Plain Text Every Round = ", plain_text_every_round)

    avalanche_effect(plain_text, plain_text_avalanche, key, key_avalanche)


if __name__ == '__main__':
    main()
