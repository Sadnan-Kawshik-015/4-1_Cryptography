"""
Author : Sadnan Kibria Kawshik
Roll:AE-15
Course : Cryptography & Security Lab
Labwork : Assignment - 1(Classical Encryption Techniques)
Problem no:1- Implementing Vigenere Cipher

Brief description :
   The problem in this assignment is to implement vigenere cipher.In case of vigenere cipher,
  If  we Assume a sequence of plaintext letters P = p 0 , p 1 , p 2 , c , p n - 1 and a key consisting of the
sequence of letters K = k 0 , k 1 , k 2 , c , k m - 1 , where typically m <= n. Here capital and lower case
letters are told to encrypt separately.So total possible alphabet is = 52(A-Z and a-z)The sequence
 of ciphertext letters C = C 0 , C 1 , C 2 , c , C n - 1 is calculated as follows:

    Ci = (Pi+ki%m)%52

    Here each letter can be mapped  to multiple letters.So it is known as poly-alphabetic cipher.In  order to
    decrypt this we use,
    Pi = (Ci - ki%m)%52

    Here lowercase and upper case letters are encrypted seperately .Plain text ,key  and cipher text
    is stored at "input.txt","key.txt" and "output.txt"
"""

# Frequency Table creation:
mapping_table = dict()#mapping  table
j = 65

for i in range(0, 26): #A-Z:0-25
    mapping_table[chr(j)] = i
    j = j + 1

j = 97
for i in range(26, 52):#(a-z):26-51
    mapping_table[chr(j)] = i
    j = j + 1


def get_key(value): #returns the key of a value in dictionary
    key_list = list(mapping_table.keys())
    val_list = list(mapping_table.values())
    position = val_list.index(value)
    key_dictionary = key_list[position]
    return key_dictionary#key of value


def process_String(path):#function to process input string
    count = 0
    output = ""
    try:
        fhand = open(path)

    except:
        print("File can't be opened")
        exit()
    # print("File is successfully opened")
    for line in fhand:
        line = line.replace('.', '')#eliminating non letter symbols
        line = line.replace(' ', '')
        line = line.replace(':','')
        line = line.replace(';',"")
        line = line.replace(',',"")
        line = line.replace('?',"")
        line = line.replace('\'',"")
        line = line.replace('!',"")

        count = count + 1
        # print(count)
        output = output + line

    fhand.close()

    return output




def vigenere_cipher_encryption(key, plain_text):#vigenere encryption based on above formula
    cipher_text = ""
    n = len(plain_text)#length of plain text
    m = len(key)#length of cipher text

    if m > n:#key can't be bigger than plain text
        print("Key  can't be bigger than plain text")

    else:
        for i in range(0, n):
            index = (mapping_table[plain_text[i]] + mapping_table[key[i % m]]) % 52 #calculating the mapped value of each cipher text letter.Here each letter is key and value is equivalent number
            ci = get_key(index)#equivalent letter
            cipher_text = cipher_text + ci#creating cipher text string

    return cipher_text#cipher text


def vigenere_cipher_decryption(key, path):#vigenere encryption based on above formula
    cipher_text = process_String("output.txt")#reading cipher text from "output.txt"
    plain_text = ""#equivalent plaintext
    n = len(cipher_text)#length of cipher text
    # print(n)
    m = len(key)

    if m > n:
        print("Key  can't be bigger than plain text")

    else:
        for i in range(0, n):
            index = (mapping_table[cipher_text[i]] - mapping_table[key[i % m]]) % 52#calculating the mapped value of each cipher text letter.Here each letter is key and value is equivalent number
            # print(index)
            pi = get_key(index)
            # print(pi)
            plain_text = plain_text + pi#equivalent plaintext


    return plain_text


def output_string_generation(ciphertext):#geneating ciphertext based on asked format

    output = ""
    i = 0
    j = 5
    x = len(ciphertext)

    while i < len(ciphertext) and x >= 5:#taking 5 char to form a word and concatinating it
        word = ciphertext[i:j]
        output = output+word + " "

        i = j
        j = j + 5
        x = x - 5
    word = ciphertext[i:]
    output = output + word
    return output#fomatted output string


def output_generation(path, ciphertext):#storing the generated formatted string  in 'output.txt
    try:
        fout = open(path, 'w')


    except:
        print("File can't be opened")
        exit()

    output = output_string_generation(ciphertext)
    print("Generated String:")
    print(output)
    fout.write(output)
    fout.close()
    print("Cipher text successfully stored at 'output.txt '")


def main():
    print("Assignment-1: Classical Encryption technique ")

    path = "input.txt"
    plain_text = process_String(path)

    print("(a) Formatted Plain text is :")
    print(plain_text)

    key = process_String("key.txt")
    print("(b)Key is : ")
    print(key)
    # print(get_key(51))
    cipher_text = vigenere_cipher_encryption(key, plain_text)
    print("Encrypted Cipher text is : ")
    print(cipher_text)
    print("(c)Output Generation : ")
    output_generation("output.txt",cipher_text)

    eq_plain_text = vigenere_cipher_decryption(key, 'output.txt')
    print("(d)Equivalent plain text is :")
    print(eq_plain_text)


if __name__ == '__main__':
    main()
