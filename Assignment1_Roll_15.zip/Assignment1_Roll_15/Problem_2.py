"""
Author : Sadnan Kibria Kawshik
Roll:AE-15
Course : Cryptography & Security Lab
Labwork : Assignment - 1(Classical Encryption Techniques)
Problem no-2: Cryptoanalysis & Cracking Vigenere cipher

Brief discussion :
  Vigenre cipher was thought to be uncrackable. But it is not unbreakable.
  We can use the repeatition of key property to break vigenere cipher.
    Kasiski showed a method to crack this.
   The kasiski method is as follows :
        1. First we will  find repeated string pattern in the cipher text & note down their distance of
        repeatation(distance of occurance)
        2. Then factorize the distance number & store the factors
        3. The factors which has appeared most frequently might be the key length or key length will be factor of them
        4. If we have found the key length, then we will try to decrypt
        6. For example if the key length is 6, we will collect every 6th character of the cipher,
        then predict the plain text with monoalphabatic cipher's cryptoanalysis. i.e replace
        the most frequent letter with the most frequent alphabet in English.
        7. We will then find the key . then predict the plain text

"""

import re
import math

mapping_table = dict()#mapping  table
j = 65

for i in range(0, 26): #A-Z:0-25
    mapping_table[chr(j)] = i
    j = j + 1

j = 97
for i in range(26, 52):#(a-z):26-51
    mapping_table[chr(j)] = i
    j = j + 1


maximum_frequency_length = 16#maximum key length
factor_frequency_table = dict()#dictionary to store frequency of each factor in order to find most common factor
dist_set = set()#as a set distance between 3/4 /5 length subsequences

def get_key(value): #returns the key of a value in dictionary
    key_list = list(mapping_table.keys())
    val_list = list(mapping_table.values())
    position = val_list.index(value)
    key_dictionary = key_list[position]
    return key_dictionary#key of value


def process_String(path):#function to process input string
    count = 0
    output = ""
    try:
        fhand = open(path)

    except:
        print("File can't be opened")
        exit()
    # print("File is successfully opened")
    for line in fhand:
        line = line.replace('.', '')#eliminating non letter symbols
        line = line.replace(' ', '')
        line = line.replace(':','')
        line = line.replace(';',"")
        line = line.replace(',',"")
        line = line.replace('?',"")
        line = line.replace('\'',"")
        line = line.replace('!',"")

        count = count + 1
        # print(count)
        output = output + line

    fhand.close()

    return output


def get_factors(x):#getting factors for each distance
    factors = list()

    for i in range(2, maximum_frequency_length + 1):
        if x % i == 0:
            factors.append(i)

    return list(set(factors))


def find_repeated_sequences_spacings(message):
    # Compile a list of repeating sequences found in the message.
    sub_spacings = {}  # keys are sequences, values are list of int spacings stored in dictionary
    for l in range(3, 6):
        for start in range(len(message) - l):
            # Determine what the sequence is, and store it in substr
            substr = message[start:start + l]

            # Search for this sequence in the rest of the message
            for i in range(start + l, len(message) - l):
                if message[i:i + l] == substr:
                    # Found a repeated sequence.
                    dist_set.add(i - start)#adding the distance to dist_set set
                    if substr not in sub_spacings:
                        sub_spacings[substr] = []  # initialize blank list

                    # Append the spacing distance between the repeated
                    sub_spacings[substr].append(i - start)

    return sub_spacings


def fill_factor_frequency_table(num):#function to fill the factor frequency dictionary for each distance
    factors = get_factors(num)
    for i in factors:
        if i not in factor_frequency_table:
            factor_frequency_table[i] = 0
        factor_frequency_table[i] = factor_frequency_table[i] + 1


def key_generation_kasiski_method(substr_spacings, dist_set):#predicting key length from kasiski method
    for val in dist_set:
        fill_factor_frequency_table(val)#filling the factor table for all distances

    sorted_dict = dict(sorted(factor_frequency_table.items(),
                              key=lambda item: item[1],
                              reverse=True))#sorting the dictionary to find most common factors

    print(sorted_dict)
    key_list = list(sorted_dict.keys())


    allLikelyKeyLengths = []#all possible key lengths
    for i in range(0, len(key_list)):
        allLikelyKeyLengths.append(key_list[i])

    return allLikelyKeyLengths


def get_nth_subkeys_letters(n, keyLength, cipher):#method to find nth subkey for n length key
    '''It is used to find each letter for a particular key length'''
    i = n - 1
    sub_string = ""
    while i < len(cipher):
        sub_string = sub_string + cipher[i]
        i += keyLength
    return sub_string

def frequency_counter(str):
    '''Counts the frequency of characters in a string and stored in a dictionary format'''
    d = {}
    for i in str:
        if i in d:
            d[i] += 1
        else:
            d[i] = 1
    return d


def generate_key_char(sub_string):
    '''Used to  generate each character of the key
    Here we calculate highest frequency letter in each column and
    find the character subtracting "E" / ''e''  based on the character' as 'E'/''e' is the most
    occuering character in the alphabate'''
    frequency_dict = frequency_counter(sub_string)
    max_key = max(frequency_dict, key=frequency_dict.get)

    if 'a' <= max_key <= 'z':
        index = (mapping_table[max_key]-mapping_table['e'])%52
        char = get_key(index)
    else :
        index = mapping_table[max_key]-mapping_table['E']%52
        char = get_key(index)

    return char

def key_generation(n,cipher):
    '''Function to generate each key based on generate_key_char() function'''
    key = ""
    d=dict()
    for i in range(0,n):
        substr = get_nth_subkeys_letters(i+1,n,cipher)
        #d = frequency_counter(substr)
        ch = generate_key_char(substr)
        key= key+ch
    return key






def generate_all_key(key_len_array, cipher):
    '''Function to generate all keys in a key list'''
    keys_list = list()
    key=""
    print(key_len_array)
    for i in key_len_array:
        key = key_generation(i,cipher)
        keys_list.append(key)

    return keys_list

def vigenere_cipher_decryption(key, cipher_text):#vigenere encryption based on above formula

    plain_text = ""#equivalent plaintext
    n = len(cipher_text)#length of cipher text
    # print(n)
    m = len(key)

    if m > n:
        print("Key  can't be bigger than plain text")

    else:
        for i in range(0, n):
            index = (mapping_table[cipher_text[i]] - mapping_table[key[i % m]]) % 52#calculating the mapped value of each cipher text letter.Here each letter is key and value is equivalent number
            # print(index)
            pi = get_key(index)
            # print(pi)
            plain_text = plain_text + pi#equivalent plaintext


    return plain_text




def main():#main function
    print("Problem-2:\nPart(a)")
    cipher = process_String("output.txt")

    print("Cleared Cipher text:")
    print(cipher)
    substr_spacings = find_repeated_sequences_spacings(cipher)
   # print(substr_spacings)
    #print(len(substr_spacings))
    # print(get_factors(72))
    all_key = key_generation_kasiski_method(substr_spacings, dist_set)
   # print(all_key[0:3])
    #print(generate_all_key(all_key[1:3],cipher))
    #str=get_nth_subkeys_letters(6,6,cipher)
    #print(generate_key_char(str))
    keys_list = generate_all_key(all_key[1:3],cipher)
    print("(a)Keys are :")
    print(keys_list)
    print("(b)Predicted Messages are : ")
    j = 1

    for i in keys_list:
        plain = vigenere_cipher_decryption(i,cipher)
        print(plain)
    print("Here 2nd string is  close to plain text as original key is of 6 length")




# the main() function.
if __name__ == '__main__':
    main()
