"""
Author : Sadnan Kibria Kawshik
Roll:AE-15
Course : Cryptography & Security Lab
Labwork : Assignment - 2(Classical Encryption Techniques)
Problem - 2(a)


Brief description :
      In this problem a new encryption technique using otp is mentioned by a student.Here,
      Let, plain text,m = m0m1...mn ,otp, p = p0p1....pn and cipher text ,c = c0c1...cn and c0 = 0
      Then, For encryption,
      c i = m i xor ((p i + c i−1 ) mod 256)

      As  c0 = 0 So, m0=p0

      Again,
       c i = m i xor ((p i + c i−1 ) mod 256)
       or, ci xor mi = ((pi+ci-1)mod 256)
       or ci xor mi xor ci = ci xor ((pi+ci-1)mod 256)
       SO, mi = ci xor ((pi + ci-1)mod256)

       It will be used for decryption

So, we will first convert all the strings involved as ascii byte array for easier xor calculation.
We will encrypt and decrypt a plain text using a key where both of length 10"""
import codecs
import math
import re


def byte_array_conversion(str):
    '''Function to convert a string as byte array'''
    ascii_array = list()
    for i in str:
        ascii_array.append(ord(i))
    byte_array = bytes(ascii_array)

    return byte_array


def accuracy_test(str_1, str_2):
    '''Function for accuracy testing which compares 2 strings and gives us
    How much they are matched'''
    matched = 0
    mis_matched = 0
    m = len(str_1)
    n = len(str_2)

    for i in range(0, m):
        if str_1[i] == str_2[i]:
            matched = matched + 1
    else:
        mis_matched = mis_matched + 1

    accuracy = matched / len(str_1)
    accuracy = accuracy * 100
    accuracy = math.floor(accuracy)
    return accuracy


def new_otp_encryption(key, plain_text):
    '''This function is based on encryption formula
    c i = m i xor ((p i + c i−1 ) mod 256)
    For easier calculation we first convert the strings as ascii byte array first
    '''
    plain_text = byte_array_conversion(plain_text)  # converting plain text as ascii byte array

    key = byte_array_conversion(key)  # converting plain text as ascii byte array

    cipher_text = bytearray()  # initializing cipher_text as ascii byte array
    xor_value = plain_text[0] ^ key[0]  # first value

    cipher_text.append(xor_value)

    for i in range(1, len(plain_text)):
        # for next values calculation
        z = (cipher_text[i - 1] + key[i]) % 256
        new_xor = plain_text[i] ^ z
        cipher_text.append(new_xor)

    return cipher_text


def new_otp_decryption(key, cipher_text):
    '''''This function is based on decryption formula
    mi = c i xor ((p i + c i−1 ) mod 256)
    For easier calculation we first convert the strings as ascii byte array first
    Here we have passed cipher_text as byte array
    '''
    key = byte_array_conversion(key)  # converting plain text as ascii byte array

    plain_text = bytearray()  # initializing cipher_text as ascii byte array
    first_element = cipher_text[0] ^ key[0]

    plain_text.append(first_element)  # first value

    for i in range(1, len(cipher_text)):
        # for next values calculation
        z = (key[i] + cipher_text[i - 1]) % 256
        element = cipher_text[i] ^ z
        plain_text.append(element)
    return plain_text.decode('utf-8')


def main():
    plain_text = 'worthiness'
    key = 'assistance'

    print("\nProblem no - 2(a)")
    print("\nHere we choose plain text and key as : ")
    print("Plain Text =  " + plain_text + " which has a length of = ", len(plain_text))
    print("Key = " + key + " which has a length of = ", len(key))
    print("\n We will now encrypt the plain text using the required encryption")
    cipher_text_array = new_otp_encryption(key, plain_text)
    cipher_text = cipher_text_array.hex()
    print("\nSo the encrypted message is = " + cipher_text)
    print("\n Now we will decrypt the cipher text and generate equivalent plain text")
    equivalent_plain_text = new_otp_decryption(key, cipher_text_array)
    print("\nSo the decrypted message is = " + equivalent_plain_text)
    print("\nWe will now calculate the accuracy of our algorithm")
    accuracy = accuracy_test(plain_text, equivalent_plain_text)
    print("\nHere the accuracy is = ", accuracy, "%")


if __name__ == '__main__':
    main()
