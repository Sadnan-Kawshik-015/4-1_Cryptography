''''Author : Sadnan Kibria Kawshik
Roll:AE-15
Course : Cryptography & Security Lab
Labwork : Assignment - 2(One Time Pad)
Problem no:1- Cracking One Time Pad

Brief description :
   In This problem two words each of 8 characters are encrypted with same one time pad.We need to find
   these words.We know that in One Time Pad(OTP) encryption technique  a plain text is paired with a random
   secret key which has a length of atleast the length of plain text.Then the key is xor ed with the plain text
   to generate the cipher text.One Time Pad normally ensures perfect secrecy as the key is randomly generated
   and is only used once.In this case,
   If a message is m and if it is encrypted with OTP ,k and the encrypted cipher text  is c
   Then,
         c = m xor k
         The operation performed here is  bitwise xor and the lengh of key,k>=length of plaintext m


   However One Time Pad(OTP) can be cracked if it is used more than once on 2 different
   plain text.The base of this is given below:

   First we need to mention some properties of xor,
   1.A xor B = C
   then A xor C = B
   and B xor C = A

   2.A xor A = 0
   3. xor operation is commutative
   4.A xor 0 = A

   let 2 plain texts as m1 and m2 and their corresponding cipher texts are c1 and c2. As same one time pad is used
   here  then,
   let,key = the otp used for encrypting the cipher

   So, c1 = m1 xor key
   and c2 = m2 xor key

   then,
   c1 xor c2 =  (m1 xor key) xor (m2 xor key)
                      =  m1 xor m2 xor key xor key
                      =m1 xor m2 xor 0
                       = m1 xor m2

So, the xor of 2 given cipher text is equal to the xor value of 2 plaintext message.

let, P= c1 xor c2 = m1 xor m2
SO,
1. m1 xor P = m1 xor (m1 xor m2) = m2
and  m2 xor P = m2 xor (m1 xor m2) = m1

So, we will first calculate the P value and for each words of dictionary we will xor it with the P value
and if the value exists in the dictionary then it is the pair

   '''
import math
import re
import codecs

word_dictionary = list()  # dictionary of words stored in list
xor_dictionary = dict()


def process_String(message):  # function to process cipher_texts.It strips the hex values and convert them as hexa strings

    output = re.sub('[^A-Za-z0-9]+', '', message)

    return output


def string_xor(s1, s2):
    '''Function to xor 2 hexadecimal string character by character'''
    i1 = int(s1, 16)
    i2 = int(s2, 16)
    output = hex(i1 ^ i2)
    return output


def hex_to_string(message):
    '''Function to convert a hexadecimal string to a string consisting of equivalent ascii characters '''
    binary_str = codecs.decode(message, "hex")
    output = str(binary_str, 'utf-8')

    return output


def string_to_hex(message):
    '''Function to convert ascii string to equivalent hexadecimal value'''
    message_hex = message.encode('utf-8')
    output = message_hex.hex()
    return output


def fill_word_dictionary():
    '''Filling up the dictionary by reading words from words.txt and selecting
    those having length of 8(as both words are 8 characters long)'''

    path = "words.txt"
    count = 0
    try:
        fhand = open(path)

    except:
        print("File can't be opened")
        exit()
        print("File is successfully opened")
    for line in fhand:
        line = re.sub('[^A-Za-z\']+', '', line)  # stripping unnecesessary characters '\n from string

        if len(line) == 8:  # as cipher texts ar length of 8 we will only consider length of 8 words from dictionary
            if line not in word_dictionary:
                count += 1
                word = line
                word_dictionary.append(word)

    fhand.close()


def word_generation(xor_value):
    '''A function that xors each word with the xored values of c1 and c2
    and then search the xor valued equivalent word in the word dictionary
    if it exists then we got our word'''

    fill_word_dictionary()
    print("\nSo the data dictionary is : ")
    print(word_dictionary)
    print("It has a length of : ", len(word_dictionary), " words")
    print("\n Now for each words in the dictionary we will xor it against the xored value"
          " of cipher text")
    print("\nThe answer will be the one which's equivalent string value resides in the word dictionary ")
    message_list = list()
    for word in word_dictionary:

        word_hex = string_to_hex(word)

        new_xor = string_xor(word_hex, xor_value)
        new_xor = new_xor[2:]  # strippin '0x' part from hexa string
        # print("\nXored Value : " + new_xor)
        check = hex_to_string(new_xor)
        # print("\nWord to test : " + check)

        if check in word_dictionary:
            message_list.append(word)
            message_list.append(check)
            return message_list


def validity_test(messages, xor_value):
    '''Function to check validity of answer'''
    m1 = messages[0]
    m2 = messages[1]
    xor = string_xor(string_to_hex(m1), string_to_hex(m2))
    xor = xor[2:]
    if xor == xor_value:
        print(m1 + " and " + m2 + " has a xor value of = ", xor, " which is equal to xor value : ", xor_value)
        return True
    else:
        print(m1 + " and " + m2 + " has a xor value of = ", xor, " which is not equal to xor value : ", xor_value)
        return False


def main():
    c1 = "e9 3a e9 c5 fc 73 55 d5"
    c2 = "f4 3a fe c7 e1 68 4a df"

    print("Assignment-2\nProblem no-1")
    print("\nThe two cipher texts given are: ")
    print(c1)
    print(c2)
    c1 = process_String(c1)
    c2 = process_String(c2)
    print("\nAfter cleaning the cipher texts are : ")
    print(c1)
    print(c2)
    # print(len(c1))

    xored_value = string_xor(c1, c2)
    xored_value = xored_value[2:]
    print("\nNow we need to calculate the xor value between 2 strings")
    print("c1 xor  c2  = ", xored_value)
    print("\nNow we will consider the words having length 8 as both cipher texts has length 8")

    messages = word_generation(xored_value)
    print("\nSo the messages are m1 = " + messages[0] + " and m2 = " + messages[1])
    print("\nWe will do a validity test\n")
    validity_test(messages, xored_value)
    print("\nSo the messages are m1 = " + messages[0] + " and m2 = " + messages[1])


if __name__ == '__main__':
    main()
