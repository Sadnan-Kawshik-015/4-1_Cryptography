"""
Author : Sadnan Kibria Kawshik
Roll:AE-15
Course : Cryptography & Security Lab
Labwork : Assignment - 2(Classical Encryption Techniques)
Problem-2(b)


Brief description :
 In this problem a new encryption technique using otp is mentioned by a student.Here,
      Let, plain text,m = m0m1...mn ,otp, p = p0p1....pn and cipher text ,c = c0c1...cn and c0 = 0
      Then, For encryption,
      c i = m i xor ((p i + c i−1 ) mod 256)

      As  c0 = 0 So, m0=p0

      Again,
       c i = m i xor ((p i + c i−1 ) mod 256)
       or, ci xor mi = ((pi+ci-1)mod 256)
       or ci xor mi xor ci = ci xor ((pi+ci-1)mod 256)
       SO, mi = ci xor ((pi + ci-1)mod256)

       It will be used for decryption

       Here 10 cipher text each of length 60 is encrypted using same pad. We need to decrypt the pad and the messages.
       As,
       They are encrypted with same pad we will  first check for every character in pad within 256 characters and
       determine the valid pad characters for each position using,
            mi = ci xor ((pi + ci-1)mod256)
            formula if mi is valid then pi will be considered and from all possible combinations of pads we will try to
            determine the pad first.We will take 15 characters combination at a time and  we will do it 4 times(0-15,16-30,31-45,46-60)
            We will concat the key_shift that gives us most valid words and then we will decrypt the messages from that pad

"""
import codecs
import math
import re
import itertools
import Trie

word_dictionary = Trie.Trie()  # word dictionary as stored as prefix tree

cipher_texts = [
    [32, 14, 162, 166, 143, 97, 199, 84, 128, 186, 67, 246, 43, 37, 76, 222, 75, 131, 131, 185, 79, 149, 100, 201,
     116, 219, 101, 188, 112, 206, 25, 63, 147, 142, 153, 112, 190, 67, 231, 37, 246, 85, 249, 123, 161, 135, 215,
     124, 193, 143, 135, 201, 67, 237, 54, 246, 74, 196, 77, 80],
    [39, 0, 27, 44, 224, 51, 18, 23, 10, 43, 233, 81, 198, 215, 123, 142, 182, 124, 137, 167, 108, 187, 67, 244,
     104, 192, 128, 151, 142, 174, 124, 225, 32, 250, 13, 90, 212, 35, 82, 206, 41, 3, 33, 236, 84, 242, 7, 60, 0,
     21, 20, 36, 167, 143, 136, 201, 104, 164, 119, 218],
    [36, 10, 29, 37, 8, 28, 68, 254, 37, 16, 233, 93, 197, 133, 236, 29, 5, 36, 253, 57, 138, 216, 26, 34, 58, 82,
     169, 192, 66, 8, 22, 123, 140, 135, 140, 137, 158, 96, 200, 64, 219, 111, 217, 82, 252, 100, 164, 158, 186,
     155, 108, 193, 75, 254, 38, 167, 159, 105, 184, 157],
    [35, 6, 19, 53, 170, 127, 168, 114, 203, 116, 131, 188, 100, 181, 139, 153, 140, 136, 220, 78, 218, 52, 196,
     114, 170, 203, 159, 246, 47, 18, 17, 56, 201, 64, 207, 94, 214, 43, 19, 9, 250, 30, 9, 5, 114, 206, 86, 251,
     18, 52, 239, 77, 144, 180, 121, 163, 151, 141, 146, 164],
    [58, 204, 20, 103, 216, 44, 2, 14, 54, 235, 45, 25, 9, 26, 42, 234, 67, 249, 8, 36, 250, 19, 164, 143, 140, 237,
     80, 245, 55, 27, 227, 75, 203, 20, 236, 60, 233, 45, 19, 15, 226, 6, 59, 248, 55, 9, 16, 59, 23, 63, 135, 205,
     66, 230, 75, 197, 109, 170, 126, 143],
    [57, 205, 18, 17, 70, 214, 112, 183, 108, 207, 47, 29, 20, 33, 72, 204, 51, 232, 51, 236, 45, 246, 19, 3, 35,
     13, 47, 8, 75, 247, 13, 114, 130, 142, 138, 146, 159, 127, 190, 8, 227, 7, 39, 236, 78, 182, 69, 255, 79, 244,
     40, 49, 243, 72, 254, 47, 27, 20, 231, 56],
    [51, 23, 237, 70, 242, 6, 99, 132, 181, 111, 141, 177, 100, 251, 98, 162, 154, 134, 155, 139, 144, 159, 99, 210,
     67, 247, 10, 32, 163, 168, 123, 161, 103, 181, 71, 148, 134, 146, 130, 158, 125, 181, 215, 77, 242, 91, 191,
     39, 61, 19, 21, 107, 172, 150, 205, 91, 236, 43, 255, 16],
    [39, 7, 25, 32, 28, 238, 27, 239, 94, 213, 103, 213, 91, 245, 76, 197, 99, 220, 34, 17, 242, 48, 216, 15, 17,
     55, 12, 38, 251, 64, 139, 164, 119, 192, 79, 156, 158, 125, 181, 111, 157, 142, 183, 107, 217, 81, 169, 152,
     172, 193, 90, 233, 63, 242, 44, 224, 4, 20, 225, 99],
    [35, 6, 31, 114, 172, 120, 185, 81, 189, 126, 131, 183, 111, 128, 179, 119, 158, 133, 144, 185, 68, 138, 143,
     142, 135, 232, 120, 202, 95, 227, 39, 10, 23, 227, 48, 233, 47, 211, 2, 4, 31, 7, 105, 169, 147, 190, 64, 168,
     172, 149, 146, 164, 98, 199, 62, 249, 79, 222, 35, 116],
    [32, 14, 162, 189, 125, 158, 131, 204, 108, 210, 45, 15, 67, 29, 10, 28, 19, 2, 4, 55, 219, 97, 189, 96, 220,
     120, 217, 99, 230, 106, 186, 223, 36, 226, 34, 228, 101, 191, 96, 234, 16, 60, 23, 10, 119, 217, 40, 3, 89,
     231, 33, 54, 237, 93, 218, 92, 128, 132, 157,
     171]]  # List of ciphertexts encrypted with same pad each has a length of 60

answer = ""


def valid_character(char_ascii):
    # the plain_text must be of the 60 valid characters
    # which are *** a – z   A – Z   space   ,  .  ?  !  -  (  )  #97-122 65-90 32 44 46 63 33 45 40 41
    # checks if the plain text char generated is a valid one
    char = chr(char_ascii)
    # print(char)
    if ('A' <= char <= 'Z') or (
            'a' <= char <= 'z') or char == ' ' or char == ',' or char == '.' or char == '?' or char == '!' or char == '-' or char == '(' or char == ')':
        return True
    else:
        return False


def key_position_generation():
    '''Function to generate valid pad characters for each position'''
    all_possible_key_list = list()
    length_of_each_cipher = len(cipher_texts[0])  # iterates all 60 position of the cyphers

    for cipher_char_index in range(length_of_each_cipher):  # for each cipher row index
        value = list()
        for pad_char in range(0, 256):  # possible pad characters for ith position
            count_valid_char = 0
            for cipher in range(len(cipher_texts)):  # iterates all 10 cyphers one by pne

                if cipher_char_index == 0:  # first position
                    cipher_previous = 0
                    cipher_current = cipher_texts[cipher][cipher_char_index]
                    plain_text_char = decryption_char_by_char(cipher_char_index, pad_char, cipher_previous,
                                                              cipher_current)
                else:
                    cipher_previous = cipher_texts[cipher][cipher_char_index - 1]
                    cipher_current = cipher_texts[cipher][cipher_char_index]
                    plain_text_char = decryption_char_by_char(cipher_char_index, pad_char, cipher_previous,
                                                              cipher_current)  # generating plain text character

                if valid_character(plain_text_char):
                    count_valid_char = count_valid_char + 1

            if count_valid_char == 10:  # if all the 10 cyphers in the ith position gives valid message char for the keychar 'p' then the keychar 'p' is valid for that position i
                value.append(chr(pad_char))
        all_possible_key_list.append(value)

    return all_possible_key_list


def cartesian_product_of_key_list(key_list):
    # cartesian product of a list of lists
    cartesian_product_list = list()
    for element in itertools.product(*key_list):
        cartesian_product_list.append(element)

    return cartesian_product_list


def decryption_char_by_char(index, pad_char, cipher_previous, cipher_current):
    # decryption using mi = ci xor ((pi + ci−1 ) mod 256)
    if index == 0:  # first index
        plain_text_char = cipher_current ^ pad_char
        return plain_text_char
    else:
        temp = (pad_char + cipher_previous) % 256
        plain_text_char = cipher_current ^ temp
        return plain_text_char


def fill_word_dictionary():
    '''Filling up the dictionary by reading words from words.txt and selecting
    those having length of 8(as both words are 8 characters long)'''

    path = "words.txt"
    count = 0
    try:
        fhand = open(path)

    except:
        print("File can't be opened")
        exit()
        print("File is successfully opened")
    for line in fhand:
        line = re.sub('[^A-Za-z]+', '', line)
        word_dictionary.add(line)
        count += 1
    print("Total word inserted = ", count)

    fhand.close()


def valid_pad_check(pad):
    '''Function to check whether a pad is valid or not by returning the ratio of good and total word'''
    total_word = 0
    good_word = 0

    for i in range(10):  # for each cipher_text
        message = ""
        for j in range(len(pad)):
            if j == 0:
                char_ascii = decryption_char_by_char(j, ord(pad[j]), 0, cipher_texts[i][j])
            else:
                char_ascii = decryption_char_by_char(j, ord(pad[j]), cipher_texts[i][j - 1], cipher_texts[i][j])
            message += chr(char_ascii)  # decrypted message

        splited_msg = re.split(r"[-!,.?()\s]\s*", message)  # splitted along special charcters

        for k in range(len(splited_msg)):
            total_word += 1  # total words in that sentence
            if word_dictionary.find_prefix(splited_msg[k])[1]:  # good words(available in dictionary
                good_word += 1
    ratio = good_word / total_word

    return ratio


def pad_generation(all_possible_pad):
    '''Function to generate pad.The idea is
    to take 2 lists at a time and generate all possible combinations among them
    and only keeping those pads that gives us the maximum ratio of good and total word
    Then we wiill put it in the list and check again iteratively until all 60 characters are found'''

    temp_list = list()  # temp list which will keep 2 lists temporarily to generate cartesian product
    list1 = all_possible_pad[0]
    temp_list.append(list1)
    possible_pad = dict()  # possible pad list

    for i in range(1, len(all_possible_pad)):
        max = 0  # to keep track of maximum ratio value
        list2 = all_possible_pad[i]
        temp_list.append(list2)
        temp_list_2 = list()  # to store possible pad and ratio pair value
        temp_cartesian = list()  # to store pad's with maximum value
        cartesian_product = cartesian_product_of_key_list(temp_list)  # cartesian product
        for j in range(len(cartesian_product)):

            x = cartesian_product[j]
            temp_str = "".join(x)
            value = valid_pad_check(temp_str)  # ratio value
            temp_list_2.append((temp_str, value))
            if value >= max:
                max = value

        print("\nThe string and good and total word ratio is :")
        print(temp_list_2)
        print("Here maximum ratio is = ", max)
        for z in range(len(temp_list_2)):
            if temp_list_2[z][1] == max:
                temp_cartesian.append(temp_list_2[z][0])  # only storing pad values with maximum ratio
        list1 = temp_cartesian  # assigning it to list1 for next iterative phase
        print("Selected pad's for phase ", i, "are = ")
        print(list1)
        temp_list.clear()  # clearing previous 2 lists
        temp_list.append(list1)  # appending the first list

    possible_pad = list1  # after 60 iterations the last value will be our pad with maximum good word ratio
    return possible_pad


def main():
    print("\nProblem no - 2(b)")
    print("We will first generate all possible pad character for each index : ")
    all_possible_pad = key_position_generation()
    for i in range(len(all_possible_pad)):
        print("Characters  of pad at index : ", i, " is : ", all_possible_pad[i], " and their lengths are : ",
              len(all_possible_pad[i]))

    print("\nNow we will fill the word dictionary and store it in a prefix tree : ")
    fill_word_dictionary()
    print("\nNow we will try to discover possible pad : ")

    possible_pad = pad_generation(all_possible_pad)
    for i in range(len(possible_pad)):
        print("\nPossible pad is = " + possible_pad[i] + " it has a length of = ", len(possible_pad))

    print("\nSo we will now generate the plain texts from this pad : ")
    for i in range(len(cipher_texts)):
        message = ""
        for k in range(len(possible_pad)):
            for j in range(len(possible_pad[k])):
                if j == 0:
                    char_ascii = decryption_char_by_char(j, ord(possible_pad[k][j]), 0, cipher_texts[i][j])
                else:
                    char_ascii = decryption_char_by_char(j, ord(possible_pad[k][j]), cipher_texts[i][j - 1],
                                                         cipher_texts[i][j])
                message += chr(char_ascii)  # decrypted message
            print("\nMessage : ", i + 1, " is = ", message)
            print("It has a length of = ", len(message))


if __name__ == '__main__':
    main()
