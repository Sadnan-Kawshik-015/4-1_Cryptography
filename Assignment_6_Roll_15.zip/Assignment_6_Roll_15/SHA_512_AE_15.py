"""
Author : Sadnan Kibria Kawshik
Roll:AE-15
Course : Cryptography & Security Lab
Labwork : Assignment - 6(SHA-512 implementation using python bitvector)

Brief description :
      SHA-512 is a cryptographic hash function that takes variable size inputs with maximum length of 2^128
       and generate 512 bit message digest.The output is processed in 1024 bits message block and several steps
       is performed to produce this hash value of 512 bits.

"""

import hashlib  # python hash library to varify answer
from BitVector import *  # importing Bitvector class

# constants

K_values = ["428a2f98d728ae22", "7137449123ef65cd", "b5c0fbcfec4d3b2f", "e9b5dba58189dbbc",
            "3956c25bf348b538", "59f111f1b605d019", "923f82a4af194f9b", "ab1c5ed5da6d8118",
            "d807aa98a3030242", "12835b0145706fbe", "243185be4ee4b28c", "550c7dc3d5ffb4e2",
            "72be5d74f27b896f", "80deb1fe3b1696b1", "9bdc06a725c71235", "c19bf174cf692694",
            "e49b69c19ef14ad2", "efbe4786384f25e3", "0fc19dc68b8cd5b5", "240ca1cc77ac9c65",
            "2de92c6f592b0275", "4a7484aa6ea6e483", "5cb0a9dcbd41fbd4", "76f988da831153b5",
            "983e5152ee66dfab", "a831c66d2db43210", "b00327c898fb213f", "bf597fc7beef0ee4",
            "c6e00bf33da88fc2", "d5a79147930aa725", "06ca6351e003826f", "142929670a0e6e70",
            "27b70a8546d22ffc", "2e1b21385c26c926", "4d2c6dfc5ac42aed", "53380d139d95b3df",
            "650a73548baf63de", "766a0abb3c77b2a8", "81c2c92e47edaee6", "92722c851482353b",
            "a2bfe8a14cf10364", "a81a664bbc423001", "c24b8b70d0f89791", "c76c51a30654be30",
            "d192e819d6ef5218", "d69906245565a910", "f40e35855771202a", "106aa07032bbd1b8",
            "19a4c116b8d2d0c8", "1e376c085141ab53", "2748774cdf8eeb99", "34b0bcb5e19b48a8",
            "391c0cb3c5c95a63", "4ed8aa4ae3418acb", "5b9cca4f7763e373", "682e6ff3d6b2b8a3",
            "748f82ee5defb2fc", "78a5636f43172f60", "84c87814a1f0ab72", "8cc702081a6439ec",
            "90befffa23631e28", "a4506cebde82bde9", "bef9a3f7b2c67915", "c67178f2e372532b",
            "ca273eceea26619c", "d186b8c721c0c207", "eada7dd6cde0eb1e", "f57d4f7fee6ed178",
            "06f067aa72176fba", "0a637dc5a2c898a6", "113f9804bef90dae", "1b710b35131c471b",
            "28db77f523047d84", "32caab7b40c72493", "3c9ebe0a15c9bebc", "431d67c49c100d4c",
            "4cc5d4becb3e42b6", "597f299cfc657e2a", "5fcb6fab3ad6faec", "6c44198c4a475817"]  # K_Values for each round
# initial buffer values
init_buffer = [
    '6a09e667f3bcc908',
    'bb67ae8584caa73b',
    '3c6ef372fe94f82b',
    'a54ff53a5f1d36f1',
    '510e527fade682d1',
    '9b05688c2b3e6c1f',
    '1f83d9abfb41bd6b',
    '5be0cd19137e2179'
]


def read_input(path):
    '''Function to read input from the file'''

    output = ""
    try:
        fhand = open(path)

    except:
        print("File can't be opened")
        exit()
    # print("File is successfully opened")
    for line in fhand:
        output = output + line

    fhand.close()

    return output


def message_padding(message):
    message_bv = BitVector(textstring=message)
    message_bv = message_bv + BitVector(bitstring="1")
    updated_message_len = message_bv.length()
    message_length = updated_message_len - 1
    zero_required = (896 - updated_message_len) % 1024
    message_bv.pad_from_right(zero_required)
    message_length_bv = BitVector(intVal=message_length, size=128)
    output = message_bv + message_length_bv
    return output


def word_generation(message_block):
    word = list()
    j = 0

    for i in range(0, 16):
        word.append(message_block[j:j + 64])
        j = j + 64

    for i in range(16, 80):
        temp_1 = word[i - 2]
        temp_2 = word[i - 15]

        sigma_0 = (temp_2.deep_copy() << 1) ^ (temp_2.deep_copy() << 8) ^ (temp_2.deep_copy().shift_right(7))
        sigma_1 = (temp_1.deep_copy() << 19) ^ (temp_1.deep_copy() << 61) ^ (temp_1.deep_copy().shift_right(6))

        result = ((int(sigma_1) + int(word[i - 7]) + int(sigma_0) + int(word[i - 16])) & 0xFFFFFFFFFFFFFFFF)

        word.append(BitVector(intVal=result, size=64))
    # print(word[16].length())

    return word


def round_function(word, init_buffer_bv, round_const):
    temp = list()

    for i in range(0, len(init_buffer_bv)):
        temp.append(init_buffer_bv[i])

    for i in range(80):
        #print("temp 4 = ", temp[4])
        ch_val = (temp[4] & temp[5]) ^ ((~temp[4]) & temp[6])
        # print(type(ch))
        maj_val = (temp[0] & temp[1]) ^ (temp[0] & temp[2]) ^ (temp[1] & temp[2])
        sum_a = ((temp[0].deep_copy()) >> 28) ^ ((temp[0].deep_copy()) >> 34) ^ ((temp[0].deep_copy()) >> 39)
        sum_e = ((temp[4].deep_copy()) >> 14) ^ ((temp[4].deep_copy()) >> 18) ^ ((temp[4].deep_copy()) >> 41)
        t1 = BitVector(intVal=(int(temp[7]) + int(ch_val) + int(sum_e) + int(word[i]) +
                               int(round_const[i])) & 0xFFFFFFFFFFFFFFFF, size=64)
        t2 = BitVector(intVal=(int(sum_a) + int(maj_val)) & 0xFFFFFFFFFFFFFFFF, size=64)
        temp[7] = temp[6]
        temp[6] = temp[5]
        temp[5] = temp[4]
        temp[4] = BitVector(intVal=(int(temp[3]) + int(t1)) & 0xFFFFFFFFFFFFFFFF, size=64)
        temp[3] = temp[2]
        temp[2] = temp[1]
        temp[1] = temp[0]
        temp[0] = BitVector(intVal=(int(t1) + int(t2)) & 0xFFFFFFFFFFFFFFFF, size=64)

    return temp


def sha_512_hash_function(message):
    init_buffer_bv = list()
    round_const_bv = list()
    # print(len(init_buffer))

    for i in range(0, len(init_buffer)):
        # print(init_buffer[i])
        init_buffer_bv.append(BitVector(hexstring=init_buffer[i]))
    for i in range(0, len(K_values)):
        # print(K_values[i])
        round_const_bv.append(BitVector(hexstring=K_values[i]))

    message_updated = message_padding(message)
    #word_generation(message_block[0:1024])

    for i in range(0,message_updated.length(),1024):
        block = message_updated[i:i+1024]
        words = word_generation(block)
        temp_list = round_function(words,init_buffer_bv,round_const_bv)

        for j in range(0,len(init_buffer_bv)):
            init_buffer_bv[j] = BitVector(intVal=(int(init_buffer_bv[j]) + int(temp_list[j])) & 0xFFFFFFFFFFFFFFFF, size=64)

    output_hash = init_buffer_bv[0]+init_buffer_bv[1]+init_buffer_bv[2]+init_buffer_bv[3]+init_buffer_bv[4]+init_buffer_bv[5]+init_buffer_bv[6]+init_buffer_bv[7]

    hash_hex_string = output_hash.getHexStringFromBitVector()

    return hash_hex_string
    # print(message_block.length())

    # print(round_const_bv[0])


def main():
    print("Assignment-6: SHA-512 implementation ")

    path = "message.txt"
    plain_text = read_input(path)
    print("Plain text for the hash function is  :")
    print(plain_text)
    hash_value = sha_512_hash_function(plain_text)

    print("Hash value from SHA-512 = ")
    print(hash_value)


if __name__ == '__main__':
    main()
