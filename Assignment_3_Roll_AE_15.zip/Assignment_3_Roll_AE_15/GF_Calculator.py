"""
Author : Sadnan Kibria Kawshik
Roll:AE-15
Course : Cryptography & Security Lab
Lab work : Assignment - 3
Problem - Implementing a calculator to carry out GF(2^8) Operations

"""


class GF_Calculator:
    '''GF(2^8) class which supports operations like addition,subtraction,multiplication and division
    It also includes  multiplicative inverse calculation'''
    irreducible_polynomial = 283  # irreducible polynomial (x^8+x^4+x^3+x+1) or 100011011
    inverse_table = dict()  # dictionary to store if i(x)*j(x) = 1 then i(x)^-1 = j(x)

    def __init__(self):
        self.fill_inverse_table()
        pass

    def fill_inverse_table(self):
        '''Function to store all multiplicative inverse of (0-255) in  a dictionary'''
        for i in range(0, 256):
            for j in range(0, 256):
                if self.multiplication(i, j) == 1:
                    self.inverse_table[i] = j

    def addition(self, a, b):
        '''Galois field addition which is  equivalent to Xor of 2 coefficients '''
        answer = a ^ b
        return answer

    def subtraction(self, a, b):
        '''Galois field subtraction which is  also equivalent to Xor of 2 coefficients'''
        answer = a ^ b
        return answer

    def multiplication(self, a, b):
        '''Galois field multiplication which is done in 2 steps first the multiplication phase is done by
        left shifting and adding the shifted terms and then if the result is >256 then the reduction phase
        is  done by calculating result modulo irreducible polynomial'''

        temp_a = decimal_to_binary(a)  # binary representation of operand a (coefficient stream)
        len_a = len(temp_a)
        result = 0  # for storing multiplication result
        for i in range(0, len_a):
            if temp_a[len_a - i - 1] == '1':
                # If operand a has 1 in its bits then the operand is first shifted i times and then it is xored with
                # result so far for example - 011*101 =(101)<<1xor(101)<<0 term with 0's is not considered as
                # multiplying something with 0 results  in  0 and xoring it with current result will return same thing

                temp_b = b << i
                result = self.addition(result, temp_b)

        if result > 255:
            # If the calculated result >255 means it is in polynomial form greater than(x^8) then we need to reduce
            # it using irreducible polynomial (x^8+x^4+x^3+x+1)

            answer = self.reduction(result,
                                    self.irreducible_polynomial)  # we will mod the result modulo irreducible polynomial

            answer = binary_to_decimal(answer)
        else:
            answer = result  # the result in within the limit

        return answer

        # print("Not Implemented Yet")

    def string_xor(self, a, b):
        '''Function to xor 2 string bitwise'''
        result = list()
        for i in range(0, len(b)):
            if a[i] == b[i]:
                result.append('0')
            else:
                result.append('1')
        return ''.join(result)

    def reduction(self, a, b):
        '''Reduction function to reduce polynomial using irreducible polynomial (x^8+x^4+x^3+x+1)'''
        bin_str_a = decimal_to_binary(a)  # Here a is dividend
        bin_str_b = decimal_to_binary(b)  # Here b is divisor
        l2 = len(bin_str_b)

        while True:
            # We will divide as long as dividend is less than divisor Divisor(irreducible polynomial) has a length of
            # 9 bit(x^8+x^4+x^3+x+1) which is 100011011 We will repeat it until result has length less than 9 until
            # then the reminder will be the next dividend and the divisor will be same a=101001010000111 has a length
            # of 15 b=100011011 has a length of 9 So I shifted b (15-9) or 6 bits first by adding 6 0's at the LSb of
            # b making it temp_b=10011011000000 Then after xoring(subtraction) a and b I removed the resultant msb
            # 0's to identify actual reminder size Do this until reminder is less than 9 bits until then assign
            # reminder of this phase will be dividend of next phase

            l1 = len(bin_str_a)
            if l1 >= l2:  # dividend length is  greater than divisor
                dif = l1 - l2
                temp_bin_str_b = bin_str_b
                for i in range(0, dif):
                    temp_bin_str_b += "0"  # indicates shifted divisor

                xor_val = self.string_xor(bin_str_a, temp_bin_str_b)  # xoring(subtracting) dividend and shifted
                # divisor to get the reminder

                result = xor_val.lstrip('0')  # removing the msb 0's to extract actual length of reminder

                if len(result) < 9:
                    # if result is within 8 bits binary then the quotient is my reduced polynomial
                    return result
                else:
                    bin_str_a = result  # assigning the quotient as the dividend

    def multiplicative_inverse(self, val):
        # returns the multiplicative inverse of a value from inverse dictionary
        return self.inverse_table[val]

    def division(self, a, b):
        '''Function for division based on a/b = a*b^-1
        Here multiplication is done based on galois field multiplication'''
        if b == 0:
            # division by 0
            result = -1  # a flag to indicate invalid result
        else:
            inverse_b = self.multiplicative_inverse(b)  # b^-1
            print("Inverse of ", b, " = ", inverse_b)
            result = self.multiplication(a, inverse_b)  # a/b = a*b^-1

        return result


def perform_operation(op_1, op_2, operation):
    '''Function to perform operation based on operator '''
    calculator = GF_Calculator()  # GF_calculator object

    answer = -1
    if operation == "+":
        answer = calculator.addition(op_1, op_2)
    elif operation == "-":
        answer = calculator.subtraction(op_1, op_2)
    elif operation == "*":
        answer = calculator.multiplication(op_1, op_2)
    elif operation == "/":
        answer = calculator.division(op_1, op_2)
    else:
        print("Invalid operator.....try again")
    return answer


def decimal_to_binary(val):
    '''Function to convert decimal to binary'''
    result = bin(val).replace("0b", "")

    return result


def binary_to_decimal(val):
    '''Function to convert binary to decimal'''
    result = int(val, 2)
    return result


def zero_to_fill(val):
    '''Function to fill remaining 0's to represent in 8 bit binary format'''
    zero_needed = ""
    for i in range(0, 8 - len(val)):
        zero_needed += "0"
    val = zero_needed + val
    return val


def valid_input_check(input):
    '''Function to check whether input is valid or not'''
    count = 0
    valid = False
    for ch in input:
        if ch == '0' or ch == '1':
            count += 1
    if count == len(input):
        valid = True
    return valid


def main():
    print("Assignment-3")
    print("GF(2^8) calculator for polynomials")
    print("Allowed operations that can be performed are: ")
    print("1.Addition(+),2.Subtraction(-),3.Multiplication(*),4.Division(/)")

    op_1 = input("\nEnter First Operand bit string of co-efficent : ")
    validity = valid_input_check(op_1)
    if not validity:
        print("Invalid Input...Not a binary string")
        return
    print("The first operand is = " + op_1 + " which in decimal is = ", binary_to_decimal(op_1))
    op_2 = input("\nEnter second operand bit string of co-efficent :  ")
    validity = valid_input_check(op_2)
    if not validity:
        print("Invalid Input...Not a binary string")
        return
    print("The second operand is = " + op_2 + " which in decimal is = ", binary_to_decimal(op_2))
    op_1 = binary_to_decimal(op_1)
    op_2 = binary_to_decimal(op_2)
    bin_str_op1 = decimal_to_binary(op_1)
    bin_str_op2 = decimal_to_binary(op_2)
    operation = input("Enter the operation you want to perform(+,-,*,/): ")
    answer = perform_operation(op_1, op_2, operation)
    if answer == -1:  # indicates illegal input
        print("Invalid Operation")
    else:
        result = decimal_to_binary(answer)

        print(zero_to_fill(bin_str_op1) + operation + zero_to_fill(bin_str_op2) + " =" + zero_to_fill(result),
              "which is in decimal = ", binary_to_decimal(result))


if __name__ == '__main__':
    main()
